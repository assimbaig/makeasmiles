const face = document.getElementById('face');
const message = document.getElementById('message');
const quote = document.getElementById('quote');

let isSad = true;

face.addEventListener('click', () => {
    if (isSad) {
        face.textContent = '😊';
        message.textContent = 'There it is — a smile!';
        quote.textContent = '"A smile is the shortest distance between two people."';
    } else {
        face.textContent = '☹️';
        message.textContent = 'Feeling low? Give me a tap.';
        quote.textContent = '"Sometimes a tiny shift makes a brighter day."';
    }
    isSad = !isSad;
});

function replay() {
    isSad = true;
    face.textContent = '☹️';
    message.textContent = 'Feeling low? Give me a tap.';
    quote.textContent = '"Sometimes a tiny shift makes a brighter day."';
}

function share() {
    alert('Share this link: https://makeasmiles.com');
}

function copyLink() {
    navigator.clipboard.writeText('https://makeasmiles.com').then(() => {
        alert('Link copied to clipboard!');
    });
}
